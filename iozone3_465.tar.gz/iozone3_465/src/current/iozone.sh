#! /bin/bash 
#This script is created by lp  in order to make izone test easily. 
#Set times this test will be conducted, one should adjust this parameter by 
#provided its value  with command line such as "./iozone-performance.sh  num". The default value of it is 3. 
#Not support sh iozone-performance.sh num , dataprocessing1 will fail. 

TESTMEM=$(free -m | grep Mem: | awk {'print $2'}) #系统内存 
TESTMEM=$(($TESTMEM / 1024))     
filesize=$(($TESTMEM + 1))    
filesize=`echo "$filesize * 2" | bc` #测试文件为2倍内存 
TESTR=32                    #测试块大小 
TESTS=$filesize              
echo $TESTS
TESTCPU=$(cat /proc/cpuinfo | grep processor | wc -l) #系统CPU核数 

dotest() { 
dat=$(date +%s -d "$time hour")
while :
do
    tim=$(date +%s)
    if [ $tim -lt $dat ];then
        ./iozone  -i 0 -i 1 -i 2 -r $TESTR -s $TESTS\g
        echo 3 > /proc/sys/vm/drop_caches 
    else
        break
    fi
done 
} 
#测试前环境准备
if [ ! -x iozone ];then
    make linux
fi
time=$1
dotest
echo "iozone test is PASS"
