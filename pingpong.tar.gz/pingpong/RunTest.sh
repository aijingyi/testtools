#!/bin/sh

#This script is created by KC based on KongWei's script(Runtest.sh.old) in order to control the repeat times of this test easily.

#Set times this test will be conducted, one should adjust this parameter by
#provided its value  with command line such as "./Runtest num". The default value of it is 3.
RUN_TIMES=5

#Remove old runnable pp32
[ -f pp32 ] && rm -f pp32
#Compile pp32
gcc -pthread -O2 pp32.c -o pp32

function table {
	GAME_NUM=$1	
    i=1
    while [ $i -le $RUN_TIMES ]; do
	 	./pp32 -v -n $GAME_NUM -i 100000 >> tmp.log
        i=`expr $i + 1`
    	sleep 1
    done
}

function resultsort {
      THEAD_NUM=`echo "$1 * 2" | bc`
      THREADS=`grep "$THEAD_NUM threads initialised" tmp.log | awk '{print $5}' |  awk '{sum+=$1} END {printf "%.2f", sum/NR}'`
      GAMES=`grep "$1 games completed" tmp.log | awk '{print $5}' |  awk '{sum+=$1} END {printf "%.2f", sum/NR}'`
      echo -e "$THEAD_NUM threads initialised in $THREADS usec \n"
      echo -e "$1 games completed in $GAMES msec \n"
      rm tmp.log
}

#Run test
table $1
resultsort $1
table $2
resultsort $2
table $3
resultsort $3

exit 0
